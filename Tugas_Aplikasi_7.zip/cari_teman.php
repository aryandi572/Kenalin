
<!DOCTYPE html>
<html>
    <head>
        <title>Cari Teman - Kenalin</title>
        <link href="css/style.css" rel="stylesheet" type="text/css" />
    </head>

    <body>
        <?php 
        include "inc/script.inc";
        include "inc/header.inc";
        require 'main/akses.inc';
        ?>
        <div class="content">
            <div class="content-status">
                <button class="tombol-status"> Cari Teman </button> <br>

                <?php
                $cari = $_GET['cari'];
                cari($cari);
                ?>
            </div>
        </div>
        <?php include "inc/footer.inc"; ?>
    </body>
</html>
