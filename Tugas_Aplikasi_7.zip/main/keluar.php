<?php
session_start();
unset($_SESSION['user']);
$pesan = "Berhasil";
header("location:../index.php?Logout=$pesan");
 ?>
