<!DOCTYPE html>
<html>
    <head>
        <title>Edit Profil - Kenalin</title>
        <link href="css/style.css" rel="stylesheet" type="text/css" />
    </head>

    <body>
        <?php
        session_start();
        include "main/connect.php";
        require 'main/akses.inc';
        $username = $_SESSION['user'];

        $tampil = $dbh->prepare("SELECT * from akun WHERE USERNAME = :USERNAME");
        $tampil->bindValue(':USERNAME', $username);
        $tampil->execute();


        $dnamaErr = $bnamaErr = $emailErr = $kotaErr = $passErr = "";

        foreach ($tampil as $row) {
            $dnama = $row['NAMA_DEPAN'];
            $bnama = $row['NAMA_BELAKANG'];
            $email = $row['EMAIL'];
            $kota = $row['KOTA'];
            $password = $row['PASSWORD'];
        }

        function val_dnama($input) {
            global $dnama, $dnamaErr;
            $dnama = trim($input);
            if (empty($dnama)) {
                $dnamaErr = "*Nama Depan Tidak Boleh Kosong";
                return false;
            } else if (!preg_match("/^[a-zA-Z ]*$/", $dnama)) {
                $dnamaErr = "*Hanya Huruf dan Spasi";
                return false;
            } else {
                return true;
            }
        }

        function val_bnama($input) {
            global $bnama, $bnamaErr;
            $bnama = trim($input);
            if (empty($bnama)) {
                $bnamaErr = "*Nama Blakang Tidak Boleh Kosong";
                return false;
            } else if (!preg_match("/^[a-zA-Z ]*$/", $bnama)) {
                $bnamaErr = "*Hanya Huruf dan Spasi";
                return false;
            } else {
                return true;
            }
        }

        function val_email($input) {
            global $email, $emailErr;
            $email = trim($input);
            if (empty($email)) {
                $emailErr = "*Email Tidak Boleh Kosong";
                return false;
            } else if (!preg_match('/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/', $email)) {
                $emailErr = "*Email Tidak Valid";
                return false;
            } else {
                return true;
            }
        }

        function val_kota($input) {
            global $kota, $kotaErr;
            $kota = trim($input);
            if (empty($kota)) {
                $kotaErr = "*Kota Tidak Boleh Kosong";
                return false;
            } else {
                return true;
            }
        }

        function val_password($passInput) {
            global $password, $passErr;
            $passInput = hash('sha256', $passInput);
            if ($password == $passInput) {
                return True;
            }
            $passErr = "Password salah";
            return False;
        }

        function panggil() {
            val_dnama($_POST['dnama']);
            val_bnama($_POST['bnama']);
            val_email($_POST['Email']);
            val_kota($_POST['Kota']);
            val_password($_POST['Password']);
            if (val_dnama(($_POST['dnama'])) && val_bnama($_POST['bnama']) && val_email($_POST['Email']) && val_kota($_POST['Kota']) && val_password($_POST['Password'])) {
                return True;
            }
        }

        if ((isset($_POST['button1'])) && (panggil())) {
            $update = $dbh->prepare("UPDATE akun SET NAMA_DEPAN = :NAMA_DEPAN, NAMA_BELAKANG = :NAMA_BELAKANG, EMAIL = :EMAIL, KOTA = :KOTA WHERE USERNAME = :USERNAME");
            $update->bindValue(':NAMA_DEPAN', $_POST['dnama']);
            $update->bindValue(':NAMA_BELAKANG', $_POST['bnama']);
            $update->bindValue(':EMAIL', $_POST['Email']);
            $update->bindValue(':KOTA', $_POST['Kota']);
            $update->bindValue(':USERNAME', $username);
            $update->execute();

            header("Location: profil.php");
        } else {
            ?>

            <?php include "inc/header.inc"; ?>
            <div class="content">
                <div class="content-edit">
                    <button class="tombol-status"> Edit Profil </button> <br>

                    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                        <div class="atur_profil_status">
                            <div>
                                Nama Depan
                                <p class="jarak"> Nama Belakang
                                <p class="jarak"> Email
                                <p class="jarak"> Kota
                                <p class="jarak"> Password
                            </div>

                            <div>
                                : <input id="dnama" name="dnama" type="text" class="input-register" value="<?php echo $dnama; ?>" />
                                <span class="error"> <?php echo $dnamaErr; ?> </span>
                                <p>
                                    : <input id="bnama" name= "bnama" type="text" class="input-register" value="<?php echo $bnama; ?>" />
                                    <span class="error"> <?php echo $bnamaErr; ?> </span>
                                <p>
                                    : <input id="Email" name= "Email" type="text" class="input-register" value="<?php echo $email; ?>" />
                                    <span class="error"> <?php echo $emailErr; ?> </span>
                                <p>
                                    : <input id="Kota" name="Kota" type="text" class="input-register" value="<?php echo $kota; ?>" />
                                    <span class="error"> <?php echo $kotaErr; ?> </span>
                                <p>
                                    : <input id="Password" name="Password" type="Password" class="input-register" value="" />
                                    <span class="error"> <?php echo $passErr; ?> </span>   
                                <p>
                                    <input type="submit" value="Ubah" name="button1" class="button-edit" />
                            </div>
                        </div>
                    </form>

                <?php }
                ?>
            </div>
        </div>
        <?php include "inc/footer.inc" ?>
    </body>
</html>
