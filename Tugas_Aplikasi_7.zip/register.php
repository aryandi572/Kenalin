
<!DOCTYPE HTML>
<html>
    <head>
        <title>Daftar Kenalin</title>
        <link rel="stylesheet" href="css/daftar.css" />
    </head>

    <body>
        <?php
        include "main/connect.php";

        $dnamaErr = $bnamaErr = $emailErr = $passErr = $confirmpassErr = $kotaErr = $tglErr = $JKErr = $unamaErr = " ";
        $dnama = $bnama = $email = $pass = $confirmpass = $tgl = $kota = $unama = $cekJK = $inputbln = $inputtgl = $inputthn = "";
        $hasiljk = false;

        function val_dnama($input) {
            global $dnama, $dnamaErr;
            $dnama = trim($input);
            if (empty($dnama)) {
                $dnamaErr = "*Nama Depan Tidak Boleh Kosong";
                return false;
            } else if (!preg_match("/^[a-zA-Z ]*$/", $dnama)) {
                $dnamaErr = "*Hanya Huruf dan Spasi";
                return false;
            } else {
                return true;
            }
        }

        function val_bnama($input) {
            global $bnama, $bnamaErr;
            $bnama = trim($input);
            if (empty($bnama)) {
                $bnamaErr = "*Nama Belakang Tidak Boleh Kosong";
                return false;
            } else if (!preg_match("/^[a-zA-Z ]*$/", $bnama)) {
                $bnamaErr = "*Hanya Huruf dan Spasi";
                return false;
            } else {
                return true;
            }
        }

        function val_email($input) {
            global $email, $emailErr;
            $email = trim($input);
            if (empty($email)) {
                $emailErr = "*Email Tidak Boleh Kosong";
                return false;
            } else if (!preg_match('/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/', $email)) {
                $emailErr = "*Email Tidak Valid";
                return false;
            } else {
                return true;
            }
        }

        function val_tgl($inputthn, $inputbln, $inputtgl) {
            global $tgl, $bulan, $tahun, $tglErr;
            $tgl = trim($inputtgl);
            $bulan = trim($inputbln);
            $tahun = trim($inputthn);
            //$lahir = $tahun.$bulan.$tgl;
            //print $lahir;
            if (empty($tgl) || empty($bulan) || empty($tgl)) {
                $tglErr = "*Tanggal Tidak Boleh Kosong";
                //return false;
            } else {
                return true;
            }
        }

        $JKErr = "";
        $cekJK = "";
        if (isset($_POST['button1'])) {
            if (empty($_POST['Pilihan'])) {
                $JKErr = "*Pilih Salah Satu";
            } else {
                $cekJK = $_POST['Pilihan'];
                $hasiljk = true;
            }
        }

        function val_kota($input) {
            global $kota, $kotaErr;
            $kota = trim($input);
            if (empty($kota)) {
                $kotaErr = "*Kota Tidak Boleh Kosong";
                return false;
            } else {
                return true;
            }
        }

        function val_UNama($input) {
            global $unama, $unamaErr;
            $unama = trim($input);
            if (empty($unama)) {
                $unamaErr = "*Nama User Tidak Boleh Kosong";
                return false;
            } else {
                return true;
            }
        }

        function val_password($input) {
            global $pass, $passErr;
            $pass = trim($input);
            if (empty($pass)) {
                $passErr = "*Sandi Tidak Boleh Kosong";
                return false;
            } else if (strlen($pass) < 7) {
                $passErr = "*Minimal password 7 digits";
                return false;
            } else {
                return true;
            }
        }

        function val_confirmPassword($input, $pass) {
            global $confirmpass, $confirmpassErr;
            $confirmpass = trim($input);
            if (empty($confirmpass)) {
                $confirmpassErr = "*Konfirm Sandi Tidak Boleh Kosong";
                return false;
            } else if ($confirmpass != $pass) {
                $confirmpassErr = "*Sandi Tidak Sama";
                return false;
            } else {
                return true;
            }
        }

        function panggil() {
            global $hasiljk;
            val_dnama($_POST['dnama']);
            val_bnama($_POST['bnama']);
            val_email($_POST['Email']);
            val_tgl($_POST['Tahun'], $_POST['Bulan'], $_POST['Tgl']);
            val_kota($_POST['Kota']);
            val_UNama($_POST['unama']);
            val_password(($_POST['passw']));
            val_confirmPassword(($_POST['passwa']), ($_POST['passw']));
            if (val_dnama(($_POST['dnama']))) {
                if (val_bnama($_POST['bnama'])) {
                    if (val_email($_POST['Email'])) {
                        if (val_tgl($_POST['Tahun'], $_POST['Bulan'], $_POST['Tgl'])) {
                            if ($hasiljk) {
                                if (val_kota($_POST['Kota'])) {
                                    if (val_UNama($_POST['unama'])) {
                                        if (val_password($_POST['passw'])) {
                                            if (val_confirmPassword($_POST['passwa'], $_POST['passw'])) {
                                                return true;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if ((isset($_POST['button1'])) && (panggil())) {
            $namadp = $_POST['dnama'];
            $namabl = $_POST['bnama'];
            $mail = $_POST['Email'];
            $jk = $_POST['Pilihan'];
            $kota = $_POST['Kota'];
            $usere = $_POST['unama'];
            $passe = $_POST['passw'];
            $lahire = $tgl . '-' . $bulan . '-' . $tahun;

            $insert = $dbh->prepare("INSERT INTO akun (NAMA_DEPAN, NAMA_BELAKANG, EMAIL, JENKEL, TGL_LAHIR, KOTA, USERNAME, PASSWORD) VALUES (:NAMA_DEPAN, :NAMA_BELAKANG, :EMAIL, :JENKEL, :TGL_LAHIR, :KOTA, :USERNAME, SHA2(:PASSWORD,0))");
            $insert->bindValue(':NAMA_DEPAN', $namadp);
            $insert->bindValue(':NAMA_BELAKANG', $namabl);
            $insert->bindValue(':EMAIL', $mail);
            $insert->bindValue(':JENKEL', $jk);
            $insert->bindValue(':TGL_LAHIR', $lahire);
            $insert->bindValue(':KOTA', $kota);
            $insert->bindValue(':USERNAME', $usere);
            $insert->bindValue(':PASSWORD', $passe);
            $insert->execute();

            header('Refresh: 5; URL=index.php');
            echo "<h3>Pendaftaran Berhasil, Tunggu beberapa saat akan mengarah ke halaman <a href='index.php'> Masuk <a></h3>";
        } else {
            ?>
            <div class="container">
                <div class="main">
                    <a href="index.php"> <img alt="logo" src="gambar/logo-regis2.png" class="logo-register"> </a>

                    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" enctype="multipart/form-data">
                        <input class="input" type="text" name="dnama" placeholder="Name Depan" value="<?php echo $dnama; ?>">
                        <div class="error"> <?php echo $dnamaErr; ?></div>

                        <input class="input" type="text" name="bnama" placeholder="Name Belakang" value="<?php echo $bnama; ?>">
                        <div class="error"><?php echo $bnamaErr; ?></div>

                        <input class="input" type="text" name="Email" placeholder="Email" value="<?php echo $email; ?>">
                        <div class="error"><?php echo $emailErr; ?></div>

                        <div id="jarak">
                            <label>Jenis Kelamin :</label>
                            <input name="Pilihan" value="L" type="radio" <?php if ($cekJK == "L") {
            echo "checked";
        } ?>>L
                            <input name="Pilihan" value="P" type="radio" <?php if ($cekJK == "P") {
            echo "checked";
        } ?>>P
                        </div>
                        <div class="error"><?php echo $JKErr; ?></div>

                        <div id="jarak2">
                            <label>Tanggal Lahir :</label>
                            <select name="Tahun">
                                <option value="" selected> Tahun </option>
    <?php for ($tahun = 2017; $tahun >= 1900; $tahun--) { ?>
                                    <option value="<?php echo $tahun; ?>">
        <?php echo $tahun; ?>
                                    </option> <?php } ?>
                            </select>

                            <select name="Bulan">
                                <option value="" selected> Bulan </option>
                                    <?php
                                    $nmbulan = array("Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agus", "Sep", "Okt", "Nov", "Des");
                                    ?>
    <?php for ($bulan = 1; $bulan <= 12; $bulan++) { ?>
                                    <option value="<?php echo $bulan; ?>">
        <?php echo $nmbulan[$bulan - 1]; ?>
                                    </option> <?php } ?>
                            </select>

                            <select name="Tgl">
                                <option selected> Tgl </option>
    <?php for ($hari = 1; $hari <= 31; $hari++) { ?>
                                    <option value="<?php echo $hari; ?>">
        <?php echo $hari; ?>
                                    </option> <?php } ?>
                            </select>
                        </div>
                        <div class="error"><?php echo $tglErr; ?></div>

                        <input class="input" type="text" name="Kota" placeholder="Kota Asal" value="<?php echo $kota; ?>">
                        <div class="error"> <?php echo $kotaErr; ?> </div>

                        <input class="input" type="text" name="unama" placeholder="Name User" value="<?php echo $unama; ?>">
                        <div class="error"><?php echo $unamaErr; ?></div>

                        <input class="input" type="password" name="passw" placeholder="Sandi" value="<?php echo $pass; ?>">
                        <div class="error"> <?php echo $passErr; ?></div>


                        <input class="input" type="password" name="passwa" placeholder="Konfirmasi Sandi" value="<?php echo $confirmpass; ?>">
                        <div class="error"><?php echo $confirmpassErr ?></div>

                        <input class="submit" type="submit" name="button1" value="Daftar">
                    </form>
                </div>
            </div>
<?php } ?>
    </body>
</html>
