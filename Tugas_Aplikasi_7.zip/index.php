<!DOCTYPE html>
<?php
include "inc/script.inc";
include "main/connect.php";
require 'main/akses.inc';
?>
<html>
    <head>
        <title>Beranda - Kenalin</title>
        <link href="css/style.css" rel="stylesheet" type="text/css" />
    </head>

    <body>
        <?php
        include "inc/header.inc";
        ?>
        <div class="content">
            <div class="content-status">
                <button class="tombol-status"> Buat Status </button> <br>
                <div class="atur_profil_status">
                    <a href="profil.php"> <img alt="logo" src="gambar/muslimah.jpg" class="profil2"> </a>
                    <form method="post" action="#">
                        <textarea rows="4" cols="50" name="status" placeholder="Apa yang Anda Pikirkan ???"></textarea>
                        <input type="submit" name="submit" value="kirim" class="tombol">
                    </form>
                </div>
                <?php echo $messageError; ?>
            </div>
            <hr>
            <?php
            statusBeranda($_SESSION['user'])
            ?>
        </div>
        <?php include "inc/footer.inc" ?>
    </body>
</html>
