<?php
include "main/connect.php";
$messageuser = $messagepass = $user = $pass = "";
session_start();
if (isset($_POST['login'])) {
    if (empty($_POST['user'])) {
        $messageuser = "Username Kosong";
        if (empty($_POST['pass'])) {
            $messagepass = "Password Kosong";
        }
    } else {
        $user = $_POST['user'];
        $pass = $_POST['pass'];
    }

    $stmt = $dbh->prepare("select * from akun where username = :username and password = SHA2(:password, 0)");
    $stmt->bindValue(":username", $user);
    $stmt->bindValue(":password", $pass);
    $stmt->execute();

    $cek = $stmt->rowCount() > 0;

    if ($cek) {
        $_SESSION['user'] = $user;
        header("Location:index.php?pesan=berhasil");
    }
}
?>
<!DOCTYPE HTML>
<html>
    <head>
        <title>Daftar Kenalin</title>
        <link rel="stylesheet" href="css/masuk.css" />
    </head>

    <body>
        <div class="container">
            <div class="main">
                <a href="index.php"> <img alt="logo" src="gambar/logo-login2.png" class="logo"> </a>

                <form method="post" action="#" enctype="multipart/form-data">
                    <label>Username</label>
                    <input id="Name" class="input" type="text" name="user" placeholder="Username">
                    <div class="error"> <?php echo $messageuser; ?></div>
                    <label>Password</label>
                    <input id="pass" class="input" type="password" name="pass" placeholder="Password">
                    <div class="error"><?php echo $messagepass; ?></div>
                    <input class="submit" type="submit" name="login" value="Masuk">
                    <p class="tulisan-register"> Mau Kenalin ? <a href="register.php"> Daftar </a></p>
                </form>
            </div>
        </div>
    </body>
</html>
