<!DOCTYPE html>
<html>
    <head>
        <?php include "inc/script.inc"; ?>
        <title>Profil - Kenalin</title>
        <link href="css/style.css" rel="stylesheet" type="text/css" />
    </head>
    <body>
        <?php
        include "inc/header.inc";
        require 'main/akses.inc';
        if (isset($_GET["profil"])) {
            $akunSekarang = $_GET["profil"];
        } else {
            $akunSekarang = $_SESSION['user'];
        }
        ?>
        <div class="content">
            <div class="content-profil-foto">
                <a href="profil.php"> <img alt="logo" src="gambar/muslimah.jpg" class="foto-profil"> </a>
                <?php
                ambilDetail($akunSekarang);
                if (!(cekPertemanan($akunSekarang))) {
                    echo "<form method='POST' action='profil.php' class='tengah'> 
                    <input type='hidden' name='kenalan' value=" . $akunSekarang . ">
                    <input class='tombolTambahTeman' type='submit' value='Kenalan'>
                </form>";
                }
                ?>

            </div>
            <hr class="batas">

            <div class="content-profil">


                <?php
                if (cekPertemanan($akunSekarang)) {
                    echo '<form method="GET" action="profil.php"> 
                            <input type="hidden" name="profil" value="' . $akunSekarang . '">
                            <input type="hidden" name="mod" value="status">
                            <input class="tombol-profil" type="submit" value="Status">
                         </form>';
                }
                echo '<form method="GET" action="profil.php"> 
                        <input type="hidden" name="profil" value="' . $akunSekarang . '">
                        <input type="hidden" name="mod" value="detail">
                        <input class="tombol-profil" type="submit" value="Detail">
                    </form>';
                if (cekPertemanan($akunSekarang)) {
                    echo '<form method="GET" action="profil.php">
                            <input type="hidden" name="profil" value="' . $akunSekarang . '">
                            <input type="hidden" name="mod" value="teman">
                            <input class="tombol-profil" type="submit" value="Teman">
                        </form>';
                }
                ?>

                <div class="posisi_nama_profil">
                    <?php
                    if (cekPertemanan($akunSekarang)) {
                        if (isset($_GET["mod"])) {
                            if ($_GET["mod"] === "teman") {
                                profilTeman($akunSekarang);
                            }if ($_GET["mod"] === "detail") {
                                profilDetail($akunSekarang);
                            }if ($_GET["mod"] === "status") {
                                profilStatus($akunSekarang);
                            }
                        } else {
                            profilStatus($akunSekarang);
                        }
                    } else {
                        profilDetail($akunSekarang);
                    }
                    ?>
                </div>
            </div>
        </div>
        <?php include "inc/footer.inc"; ?>
    </body>
</html>

